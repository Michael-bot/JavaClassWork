package edu.gcccd.csis;

public class Rectangle
{
    private double width, length ;
    private static int numOfRectangles=0;

    public Rectangle(double width, double length) {
        this.width = width;
        this.length = length;
        numOfRectangles++;
    }

    public Rectangle() {
        this.width = 1;
        this.length = 1;
        numOfRectangles++;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }
    public double getArea()
    {
        return width*length;
    }
    public double getCircumference()
    {
        return 2*(length+width);
    }
    public boolean isSquare()
    {
        return width==length;
    }
}