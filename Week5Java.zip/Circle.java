package edu.gcccd.csis;

public class Circle
{
    private double radius;
    private String color;
    private static int numOfCircles=0;

    public Circle() {
        this.radius=0;
        numOfCircles++;
    }


    public Circle(double radius, String color)
    {
        this.radius = radius;
        this.color = color;
        numOfCircles++;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getRadius() {
        return radius;
    }

    public double getArea()
    {
        return Math.PI*radius*radius;
    }
    public double getCircumference()
    {
        return 2*Math.PI*radius;
    }

}