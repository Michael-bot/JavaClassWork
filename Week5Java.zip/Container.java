package edu.gcccd.csis;

public class Container
{
    private Rectangle rectangle;
    private Circle circle;

    public Rectangle getRectangle() {
        return rectangle;
    }

    public void setRectangle(Rectangle rectangle) {
        this.rectangle = rectangle;
    }

    public Circle getCircle() {
        return circle;
    }

    public void setCircle(Circle circle) {
        this.circle = circle;
    }

    public int size()
    {
        if(rectangle==null && circle==null)
            return 0;
        else if (rectangle!=null || circle!=null)
            return 1;
        else
            return 2;
    }
}